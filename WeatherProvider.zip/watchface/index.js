﻿	/********************************
	*								*
	*		WeatherProvider			*
	*			   v1.4				*
	*		2025 © leXxiR [4pda]	*
	*								*
	********************************/
  
    try {
    (() => {

        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        

        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2

		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);

		let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText



	//------------- вибро ------------------
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(mode = 25, stopDelay = 30) {
			vibrator.stop();
			vibrator.scene = mode;
			vibrator.start();
			stopVibro_Timer = setTimeout(() => {
				stopVibro();
			}, stopDelay);
		}		

		function stopVibro(){
			vibrator.stop();
			if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
		}



	/********  класс Провайдер погоды  ********/
	/******				v1.4			*******/
	/******		2025 © leXxiR [4pda]	*******/

		class WeatherProvider {
		  constructor(props = {}) {
			this.props = {
				night_icons: [],											// индексы иконок для замены день-ночь
				index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
				show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
				temp_widget: null,											// виджет TEXT для отображения температуры
				temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
				temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
				temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
				description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
				cityName_widget: null,										// виджет TEXT для отображения названия города
				icon_widget: null,											// виджет IMG для отображения значка погоды
				time_sensor: null,											// сенсор времени, если не задан, то создается новый
				weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
				file_name: 'weather.json',									// имя файла с погодными данными
				auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
				lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
				...props,
			};

			this.providers = [
							{name: ['Zepp', 'Zepp'], appId: null},							// 0
							{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
							{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
						]

			this.description = [
					['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
					['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
				]

			this.last = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
				modTime: null,
			}

			if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
			if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
			if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
			if (this.props.auto_update) this.createHandlers();
		  }

		// создание обработчиков автоматического обновления погоды
			createHandlers() {
				this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

				this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: ( () => this.update() )
				})
			}
 
		// служебные функции
			arrayBufferToCyrillic(buffer) {
			  let result = '';
			  const bytes = new Uint8Array(buffer);

			  let i = 0;
			  while (i < bytes.length) {
				let byte1 = bytes[i++];
				
				if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
				  result += String.fromCharCode(byte1);
				} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
				  let byte2 = bytes[i++];
				  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
				  result += String.fromCharCode(charCode);
				} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
				  let byte2 = bytes[i++];
				  let byte3 = bytes[i++];
				  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
				  result += String.fromCharCode(charCode);
				}
			  }

			  return result
			}

		// чтение погодных данных из файла
			readFile(app_id) {
			  if (!app_id) return null				
			  let str_result = "";
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				if (err == 0) {
				  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
					appid: app_id,
				  });

				  const len = fs_stat.size;
				  let array_buffer = new ArrayBuffer(len);
				  hmFS.read(fh, array_buffer, 0, len);
				  hmFS.close(fh);
				  str_result = this.arrayBufferToCyrillic(array_buffer);

				  return str_result;
				} else {
				  console.log("err:", err);
				}
			  } catch (error) {
				console.log("error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
			  return null;
			}

		// получить время последнего изменеия файла
			getFileModTime(app_id) {
			  if (!app_id) return null
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				
				if (err == 0) {
				  return fs_stat.mtime
				} else {
				  console.log("ModTime err:", err);
				}
			  } catch (error) {
				console.log("ModTime error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
				return null
			}

		// проверка времени суток: возвращает true, если сейчас день
			isDayNow() {
				const sunData = this.props.weather_sensor.getForecastWeather().tideData;
				let sunriseMins = 8 * 60;			// время восхода
				let sunsetMins = 20 * 60;			// и заката по умолчанию

				if (sunData.count > 0){
					const today = sunData.data[0];
					sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
					sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
				}

				const curMins = curTime.hour * 60 + curTime.minute;
				const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

				return nowIsDay
			}


		// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
			getZeppIconIndex(index, app_id = null) {
				
				if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

				let newIndex = 25;
				
				if (app_id == 1065824) {					// WeatherService
					switch(index) {
					   case 1:
							newIndex = 3;
						break;
					   case 2:
							newIndex = 0;
						break;
					   case 3:
					   case 4:
							newIndex = 4;
						break;
					   case 5:
							newIndex = 1;
						break;
					   case 6:
							newIndex = 5;
						break;
					   case 7:
							newIndex = 10;
						break;
					   case 8:
							newIndex = 15;
						break;
					   case 9:
							newIndex = 6;
						break;
					   case 10:
							newIndex = 8;
						break;
					   case 11:
							newIndex = 9;
						break;
					   case 12:
							newIndex = 12;
						break;
					   case 13:
							newIndex = 13;
						break;
					   case 14:
							newIndex = 17;
						break;
					   default:
							newIndex = 25;
						break;
					}
				} else if (app_id == 1066654) {					// RuWeather
					newIndex = index - 1;
				}

				return newIndex
			}

		// температура со знаком
			tempWithSign(val){
				val = parseFloat(val);
				if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
				val = Math.round(val);
				if (val > 0) val = '+' + val;
				val += '°';
				
				return val
			}

		//получение погодных данных из Zepp
			getZeppWeatherData() {
				const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
				const data = {
					weatherIcon: iconIndex,
					weatherDescription:  this.description[this.props.lang][iconIndex],
					temperature: this.props.weather_sensor.current ?? '--',
					temperatureFeels: '--',
					temperatureMax: this.props.weather_sensor.high ?? '--',
					temperatureMin: this.props.weather_sensor.low ?? '--',
					cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
				}

				return data
			}

		//получение погодных данных из файла приложения
			getAppWeatherData(app_id) {
				const data = {
					weatherIcon: 25,
					weatherDescription:  'Нет данных',
					temperature: '--',
					temperatureFeels: '--',
					temperatureMax: '--',
					temperatureMin: '--',
					cityName: '--',
				}

				// читаем данные из файла данных приложения
				let weather_str = this.readFile(app_id);
				let weatherJson = JSON.parse(weather_str);
		  
				if (weatherJson) {
					if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
					  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
					}

					if (weatherJson?.weatherDescriptionExtended?.length) {
					  data.weatherDescription = weatherJson.weatherDescriptionExtended;
					  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
					} else data.weatherDescription = this.description[data.weatherIcon];

					if (isFinite(weatherJson.temperature)) {
					  data.temperature = parseFloat(weatherJson.temperature);
					  data.temperature = Math.round(data.temperature);
					}
					
					if (isFinite(weatherJson.temperatureFeels)){
						data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
						data.temperatureFeels = Math.round(data.temperatureFeels);
					}
					  
					if (isFinite(weatherJson.temperatureMax)){
						data.temperatureMax = parseFloat(weatherJson.temperatureMax);
						data.temperatureMax = Math.round(data.temperatureMax);
					}
					  
					if (isFinite(weatherJson.temperatureMin)){
						data.temperatureMin = parseFloat(weatherJson.temperatureMin);
						data.temperatureMin = Math.round(data.temperatureMin);
					}
					
					if (weatherJson.city) {
					  data.cityName = weatherJson.city;
					}
				}
				
				return data
			}

		//получение погодных данных из файла приложения или Zepp
			getWeatherData(app_id = null) {
				if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
				else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
			}

		// обновить виджеты, используя данные текущего провайдера
			update() {
				let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

				const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
				
				if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
					const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
					this.last.modTime = modTime;

					let val = this.tempWithSign(newData.temperature);
					if (val != this.last.temperature){
						this.last.temperature = val;
						if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMax);
					if (val != this.last.temperatureMax){
						this.last.temperatureMax = val;
						if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMin);
					if (val != this.last.temperatureMin){
						this.last.temperatureMin = val;
						if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureFeels);
					if (val != this.last.temperatureFeels){
						this.last.temperatureFeels = val;
						if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = newData.cityName;
					if (val != this.last.cityName){
						this.last.cityName = val;
						if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = newData.weatherDescription;
					if (val != this.last.weatherDescription){
						this.last.weatherDescription = val;
						if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
					}

					
					curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
				}

				if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
					curIcon += 'n';
				}

				if (curIcon != this.last.weatherIcon){
					this.last.weatherIcon = curIcon;
					if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
				}
			}

		// переключить на следующего провайдера
			next(show_toast = this.props.show_toast) {
				const v = (this.props.index + 1) % this.providers.length;
				this.provider = v;
				if (show_toast) hmUI.showToast({text: this.name});
			}

		// переключить на предыдующего провайдера
			prev(show_toast = this.props.show_toast) {
				const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
				this.provider = v;
				if (show_toast) hmUI.showToast({text: this.name});
			}

		// переключить назад или вперед
			toggle(dir, show_toast = this.props.show_toast) {
				if (dir > 0) this.next(show_toast)
				else this.prev(show_toast);
			}
			
		// установить провайдера по индексу
			set provider(v) {
				this.props.index = v;
				hmFS.SysProSetInt('WeatherProviderIndex', v);
				this.update();
			}

		// получить индекс текущего провайдера
			get index() {
				return this.props.index
			}

		// получить название текущего провайдера
			get name() {
				return this.providers[this.props.index].name[this.props.lang]
			}

		// получить название города
			get cityName() {
				return this.last.cityName
			}

		// получить текущую температуру
			get temperature() {
				return this.last.temperature
			}

		// получить максимальную температуру
			get temperatureMax() {
				return this.last.temperatureMax
			}

		// получить минимальную температуру
			get temperatureMin() {
				return this.last.temperatureMin
			}

		// получить ощущаемую температуру
			get temperatureFeels() {
				return this.last.temperatureFeels
			}

		// получить описание погоды
			get weatherDescription() {
				return this.last.weatherDescription
			}

		// удалить
		  delete() {
			this.providers = null;
			this.props = null;
			this.last = null;
			this.description = null;
			if (this.widgetDelegate) {
				hmUI.deleteWidget(this.widgetDelegate);
				this.widgetDelegate = null;
			}
		  }

		}



//----------------------------------------------------------------------------------------
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            normalWF() {

			cityNameText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 50,
			  y: 60,
			  w: DEVICE_WIDTH - 100,
			  h: 40,
			  text_size: 32,
			  text: '--',
			  color: 0xffffff,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});


			const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: centerX - 120,
              y: 110,
              w: 240,
              h: 120,
            });

            weatherInfo.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 240,
              h: 120,
			  radius: 10,
              color: 0x222222,
            });

			weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
			  x: 20,
			  y: 20,
			  w: 60,
			  h: 60,
			  src: 'w_25.png',
			});

			tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
			  x: 80,
			  y: 25,
			  w: 100,
			  h: 50,
			  text_size: 42,
			  text: '--',
			  color: 0xffffff,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});

			tempMinText = weatherInfo.createWidget(hmUI.widget.TEXT, {
			  x: 180,
			  y: 46,
			  w: 60,
			  h: 40,
			  text_size: 24,
			  text: '--',
			  color: 0x999999,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});

			tempMaxText = weatherInfo.createWidget(hmUI.widget.TEXT, {
			  x: 180,
			  y: 15,
			  w: 60,
			  h: 40,
			  text_size: 24,
			  text: '--',
			  color: 0x999999,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});

			weatherInfo.createWidget(hmUI.widget.TEXT, {
			  x: 15,
			  y: 85,
			  w: 160,
			  h: 40,
			  text_size: 24,
			  text: 'Ощущается ',
			  color: 0xaaaaaa,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});

			tempFeelsText = weatherInfo.createWidget(hmUI.widget.TEXT, {
			  x: 180,
			  y: 83,
			  w: 60,
			  h: 40,
			  text_size: 26,
			  text: '--',
			  color: 0xcccccc,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});

			descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 0,
			  y: 235,
			  w: DEVICE_WIDTH,
			  h: 40,
			  text_size: 30,
			  text: '--',
			  color: 0xcccccc,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V
			});



		// экземпляр класса
			const weatherProvider = new WeatherProvider({
				night_icons: [0, 1, 2, 3, 14],
				show_toast: false,
				temp_widget: tempText,
				temp_max_widget: tempMaxText,
				temp_min_widget: tempMinText,
				temp_feels_widget: tempFeelsText,
				description_widget: descriptionText,
				cityName_widget: cityNameText,
				icon_widget: weatherImg,
				time_sensor: curTime,
				weather_sensor: weather,
			});



		// название провайдера погоды
            hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: centerX - 190,
              y: DEVICE_HEIGHT - 160,
              w: 380,
              h: 40,
			  radius: 20,
              color: 0x999999,
            });
			
			const weatherProviderName = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: DEVICE_HEIGHT - 165,
				w: DEVICE_WIDTH,
				h: 50,
				text_size: 30,
				text: weatherProvider.name,
				color: 0x000000,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});


			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: centerX - 100,
              y: DEVICE_HEIGHT - 100,
              w: 80,
              h: 70,
			  text: '<',
			  text_size: 36,
			  normal_color: 0x222222,
			  press_color: 0x454545,
			  radius: 10,
			  click_func: () => {
				vibro();
				weatherProvider.prev(true);
				weatherProviderName.setProperty(hmUI.prop.TEXT, weatherProvider.name);
			  }
			});	

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: centerX + 20,
              y: DEVICE_HEIGHT - 100,
              w: 80,
              h: 70,
			  text: '>',
			  text_size: 36,
			  normal_color: 0x222222,
			  press_color: 0x454545,
			  radius: 10,
			  click_func: () => {
				vibro();
				weatherProvider.next();
				weatherProviderName.setProperty(hmUI.prop.TEXT, weatherProvider.name);
			  }
			});	


            },
            onInit() {
            },
            build() {
				this.normalWF();
            },
            onDestroy() {
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}